exportCSVBtn.addEventListener("click", async () => {
  const surveys = await getAllSurveys();
  if (!surveys.length) {
    alert("Keine Umfragen vorhanden.");
    return;
  }
  let csvContent = "Titel;Frage;Antwort\n";
  surveys.forEach((s) => {
    s.questions.forEach((q) => {
      q.options.forEach((opt) => {
        csvContent += `${s.title};${q.questionText};${opt.text}\n`;
      });
    });
  });
  downloadCSV(csvContent, "umfragen.csv");
});

exportPDFBtn.addEventListener("click", async () => {
  const surveys = await getAllSurveys();
  if (!surveys.length) {
    alert("Keine Umfragen vorhanden.");
    return;
  }
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  let yOffset = 10;

  surveys.forEach((s) => {
    doc.text(`Umfrage: ${s.title}`, 10, yOffset);
    yOffset += 8;
    s.questions.forEach((q) => {
      let rows = [];
      q.options.forEach((opt) => {
        rows.push([q.questionText, opt.text]);
      });
      doc.autoTable({
        head: [["Frage", "Antwort"]],
        body: rows,
        startY: yOffset,
      });
      yOffset = doc.previousAutoTable.finalY + 10;
    });
  });

  doc.save("umfragen.pdf");
});

function downloadCSV(csvString, filename) {
  const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
