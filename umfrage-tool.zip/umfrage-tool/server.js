const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.static(path.join(__dirname)));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

mongoose
  .connect("mongodb://localhost:27017/umfrage_tool", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => console.log("Mit MongoDB verbunden."))
  .catch((err) => console.error("Fehler bei MongoDB-Verbindung:", err));

const UserSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, required: true, enum: ["admin", "participant"] },
  createdAt: { type: Date, default: Date.now },
});
const User = mongoose.model("User", UserSchema);

const authenticate = (req, res, next) => {
  const token = req.headers.authorization?.split(" ")[1];
  if (!token) {
    return res.status(401).json({ message: "Nicht autorisiert" });
  }
  try {
    const decoded = jwt.verify(token, "dein-geheimes-jwt-schluessel");
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ message: "Ungültiges Token" });
  }
};

app.post("/register", async (req, res) => {
  const { username, email, password, role } = req.body;
  try {
    if (!["admin", "participant"].includes(role)) {
      return res.status(400).json({ message: "Ungültige Rolle!" });
    }

    const existingUser = await User.findOne({ $or: [{ username }, { email }] });
    if (existingUser) {
      return res
        .status(400)
        .json({ message: "Benutzername oder E-Mail existiert bereits." });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({
      username,
      email,
      password: hashedPassword,
      role,
    });
    await newUser.save();
    res.status(201).json({ message: "Benutzer erfolgreich registriert" });
  } catch (error) {
    res.status(500).json({ message: "Fehler bei der Registrierung" });
  }
});

app.post("/login", async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(400).json({ message: "Ungültige Anmeldedaten" });
    }
    const token = jwt.sign(
      { userId: user._id, email: user.email, role: user.role },
      "dein-geheimes-jwt-schluessel",
      { expiresIn: "1h" }
    );
    res.json({ message: "Login erfolgreich", token, role: user.role });
  } catch (error) {
    res.status(500).json({ message: "Fehler bei der Anmeldung" });
  }
});

const SurveySchema = new mongoose.Schema({
  title: { type: String, required: true },
  questions: [
    {
      questionText: { type: String, required: true },

      options: [
        {
          text: String,
        },
      ],
    },
  ],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  createdAt: { type: Date, default: Date.now },
});
const Survey = mongoose.model("Survey", SurveySchema);

const ResponseSchema = new mongoose.Schema({
  surveyId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Survey",
    required: true,
  },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  answers: [{ question: String, selectedOption: String }],
  createdAt: { type: Date, default: Date.now },
});
const Response = mongoose.model("Response", ResponseSchema);

app.post("/surveys", authenticate, async (req, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ message: "Zugriff verweigert" });
  }
  const { title, questions } = req.body;
  try {
    const newSurvey = new Survey({
      title,
      questions,
      createdBy: req.user.userId,
    });
    await newSurvey.save();
    res
      .status(201)
      .json({ message: "Umfrage erfolgreich erstellt!", survey: newSurvey });
  } catch (error) {
    res.status(500).json({ message: "Fehler beim Erstellen der Umfrage" });
  }
});

app.get("/surveys", authenticate, async (req, res) => {
  try {
    const surveys = await Survey.find({});
    res.json(surveys);
  } catch (error) {
    res.status(500).json({ message: "Fehler beim Abrufen der Umfragen" });
  }
});

app.put("/surveys/:id", authenticate, async (req, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ message: "Zugriff verweigert" });
  }
  const { title, questions } = req.body;
  try {
    const updatedSurvey = await Survey.findByIdAndUpdate(
      req.params.id,
      { title, questions },
      { new: true }
    );
    if (!updatedSurvey) {
      return res.status(404).json({ message: "Umfrage nicht gefunden" });
    }
    res.json({ message: "Umfrage aktualisiert", survey: updatedSurvey });
  } catch (err) {
    res.status(500).json({ message: "Fehler beim Aktualisieren" });
  }
});

app.delete("/surveys/:id", authenticate, async (req, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ message: "Zugriff verweigert" });
  }
  try {
    const deletedSurvey = await Survey.findByIdAndDelete(req.params.id);
    if (!deletedSurvey) {
      return res.status(404).json({ message: "Umfrage nicht gefunden" });
    }
    res.json({ message: "Umfrage gelöscht" });
  } catch (err) {
    res.status(500).json({ message: "Fehler beim Löschen" });
  }
});

app.delete("/surveys-all", authenticate, async (req, res) => {
  if (req.user.role !== "admin") {
    return res.status(403).json({ message: "Zugriff verweigert" });
  }
  try {
    await Survey.deleteMany({});
    res.json({ message: "Alle Umfragen wurden gelöscht." });
  } catch (err) {
    res.status(500).json({ message: "Fehler beim Löschen aller Umfragen" });
  }
});

app.post("/responses", authenticate, async (req, res) => {
  if (req.user.role !== "participant") {
    return res.status(403).json({ message: "Nur Teilnehmer dürfen antworten" });
  }
  const { surveyId, answers } = req.body;

  const existing = await Response.findOne({
    surveyId,
    userId: req.user.userId,
  });
  if (existing) {
    return res
      .status(400)
      .json({ message: "Du hast bereits auf diese Umfrage geantwortet." });
  }

  try {
    const newResponse = new Response({
      surveyId,
      userId: req.user.userId,
      answers,
    });
    await newResponse.save();
    res.status(201).json({ message: "Antworten erfolgreich gespeichert!" });
  } catch (error) {
    res.status(500).json({ message: "Fehler beim Speichern der Antworten" });
  }
});

app.get("/responses", authenticate, async (req, res) => {
  try {
    const allResponses = await Response.find({});
    res.json(allResponses);
  } catch (err) {
    res.status(500).json({ message: "Fehler beim Laden der Antworten" });
  }
});
app.delete("/responses", authenticate, async (req, res) => {
  if (req.user.role !== "participant") {
    return res
      .status(403)
      .json({ message: "Nur Teilnehmer dürfen ihre Antworten löschen." });
  }
  try {
    await Response.deleteMany({ userId: req.user.userId });
    res.json({ message: "Alle deine Antworten wurden gelöscht." });
  } catch (err) {
    res.status(500).json({ message: "Fehler beim Löschen der Antworten." });
  }
});

app.use((req, res, next) => {
  res.status(404).json({ message: "Route nicht gefunden" });
});

app.listen(PORT, () => {
  console.log(`Server läuft auf http://localhost:${PORT}`);
});
