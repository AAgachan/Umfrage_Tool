const surveyContainer = document.getElementById("surveyContainer");
const participantForm = document.getElementById("participantForm");
const exportAnswersCSV = document.getElementById("exportAnswersCSV");
const exportAnswersPDF = document.getElementById("exportAnswersPDF");
const deleteAllAnswersBtn = document.getElementById("deleteAllAnswers");

document.addEventListener("DOMContentLoaded", async () => {
  await loadSurveys();
});

async function loadSurveys() {
  try {
    const response = await fetch("http://localhost:3000/surveys", {
      headers: {
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    });
    const surveys = await response.json();

    surveys.forEach((s) => {
      const titleEl = document.createElement("h4");
      titleEl.textContent = s.title;
      surveyContainer.appendChild(titleEl);

      s.questions.forEach((q, qIndex) => {
        const qText = document.createElement("p");
        qText.textContent = q.questionText;
        surveyContainer.appendChild(qText);

        q.options.forEach((opt, oIndex) => {
          const label = document.createElement("label");
          label.style.display = "block";

          const cb = document.createElement("input");
          cb.type = "checkbox";
          cb.name = `survey-${s._id}-question-${qIndex}`;
          cb.value = opt.text;

          cb.addEventListener("change", () => {
            if (cb.checked) {
              const siblings = document.getElementsByName(
                `survey-${s._id}-question-${qIndex}`
              );
              siblings.forEach((sib) => {
                if (sib !== cb) sib.checked = false;
              });
            }
          });

          label.appendChild(cb);
          label.appendChild(document.createTextNode(" " + opt.text));
          surveyContainer.appendChild(label);
        });
      });
      surveyContainer.appendChild(document.createElement("hr"));
    });
  } catch (err) {
    console.error(err);
  }
}

participantForm.addEventListener("submit", async (evt) => {
  evt.preventDefault();

  try {
    const res = await fetch("http://localhost:3000/surveys", {
      headers: {
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    });
    const allSurveys = await res.json();

    for (let s of allSurveys) {
      const answersArr = [];
      s.questions.forEach((q, qIndex) => {
        const checkboxes = document.getElementsByName(
          `survey-${s._id}-question-${qIndex}`
        );
        let chosen = null;
        checkboxes.forEach((cb) => {
          if (cb.checked) chosen = cb.value;
        });
        if (chosen) {
          answersArr.push({
            question: q.questionText,
            selectedOption: chosen,
          });
        }
      });
      if (answersArr.length > 0) {
        const bodyData = {
          surveyId: s._id,
          answers: answersArr,
        };
        const postRes = await fetch("http://localhost:3000/responses", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
          body: JSON.stringify(bodyData),
        });
        if (!postRes.ok) {
          console.error("Fehler beim Senden:", await postRes.json());
        }
      }
    }

    alert("Antworten abgeschickt (wo angekreuzt).");
  } catch (err) {
    console.error("Fehler beim Abschicken:", err);
  }
});

async function loadAllResponses() {
  const res = await fetch("http://localhost:3000/responses", {
    headers: {
      Authorization: "Bearer " + localStorage.getItem("token"),
    },
  });
  return res.json();
}

deleteAllAnswersBtn.addEventListener("click", async () => {
  if (!confirm("Wirklich alle eigenen Antworten löschen?")) return;
  try {
    const delRes = await fetch("http://localhost:3000/responses", {
      method: "DELETE",
      headers: {
        Authorization: "Bearer " + localStorage.getItem("token"),
      },
    });
    if (delRes.ok) {
      alert("Alle deine Antworten wurden gelöscht.");
    } else {
      const error = await delRes.json();
      alert("Fehler: " + (error.message || "Unbekannter Fehler"));
    }
  } catch (err) {
    console.error("Fehler beim Antworten-Löschen:", err);
  }
});
