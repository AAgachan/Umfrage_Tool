document.addEventListener("DOMContentLoaded", () => {
  const addQuestionBtn = document.getElementById("addQuestion");
  const questionsContainer = document.getElementById("questionsContainer");
  const feedback = document.getElementById("feedback");
  const surveyForm = document.getElementById("surveyForm");
  const surveysList = document.getElementById("surveysList");
  const deleteAllBtn = document.getElementById("deleteAllSurveys");
  const exportCSVBtn = document.getElementById("exportCSV");
  const exportPDFBtn = document.getElementById("exportPDF");

  addQuestionBtn.addEventListener("click", () => {
    const questionBlock = document.createElement("div");
    questionBlock.classList.add("mb-3", "p-2", "border", "questionBlock");

    const questionInput = document.createElement("input");
    questionInput.type = "text";
    questionInput.name = "question";
    questionInput.placeholder = "Frage eingeben";
    questionInput.classList.add("form-control", "mb-2");
    questionInput.required = true;

    const editQBtn = document.createElement("button");
    editQBtn.type = "button";
    editQBtn.textContent = "Frage bearbeiten";
    editQBtn.classList.add("btn", "btn-warning", "btn-sm", "me-2");
    editQBtn.addEventListener("click", () => {
      questionInput.disabled = false;
    });

    const saveQBtn = document.createElement("button");
    saveQBtn.type = "button";
    saveQBtn.textContent = "Frage speichern";
    saveQBtn.classList.add("btn", "btn-info", "btn-sm", "me-2");
    saveQBtn.addEventListener("click", () => {
      questionInput.disabled = true;
    });

    const deleteQBtn = document.createElement("button");
    deleteQBtn.type = "button";
    deleteQBtn.textContent = "Frage löschen";
    deleteQBtn.classList.add("btn", "btn-danger", "btn-sm", "me-2");
    deleteQBtn.addEventListener("click", () => {
      questionBlock.remove();
    });

    const optionsContainer = document.createElement("div");
    optionsContainer.classList.add("ms-3");

    const addOptionBtn = document.createElement("button");
    addOptionBtn.type = "button";
    addOptionBtn.textContent = "Antwort hinzufügen";
    addOptionBtn.classList.add("btn", "btn-success", "btn-sm", "my-2");
    addOptionBtn.addEventListener("click", () => {
      addOption(optionsContainer);
    });

    questionBlock.appendChild(questionInput);
    questionBlock.appendChild(editQBtn);
    questionBlock.appendChild(saveQBtn);
    questionBlock.appendChild(deleteQBtn);
    questionBlock.appendChild(optionsContainer);
    questionBlock.appendChild(addOptionBtn);

    questionsContainer.appendChild(questionBlock);
  });

  function addOption(container) {
    const optionBlock = document.createElement("div");
    optionBlock.classList.add("input-group", "mb-2");

    const optionInput = document.createElement("input");
    optionInput.type = "text";
    optionInput.name = "option";
    optionInput.placeholder = "Antwort eingeben";
    optionInput.classList.add("form-control");
    optionInput.required = true;

    const editOptBtn = document.createElement("button");
    editOptBtn.type = "button";
    editOptBtn.textContent = "Antwort bearbeiten";
    editOptBtn.classList.add("btn", "btn-warning", "btn-sm", "me-2");
    editOptBtn.addEventListener("click", () => {
      optionInput.disabled = false;
    });

    const saveOptBtn = document.createElement("button");
    saveOptBtn.type = "button";
    saveOptBtn.textContent = "Antwort speichern";
    saveOptBtn.classList.add("btn", "btn-info", "btn-sm", "me-2");
    saveOptBtn.addEventListener("click", () => {
      optionInput.disabled = true;
    });

    const deleteOptBtn = document.createElement("button");
    deleteOptBtn.type = "button";
    deleteOptBtn.textContent = "Antwort löschen";
    deleteOptBtn.classList.add("btn", "btn-danger", "btn-sm", "me-2");
    deleteOptBtn.addEventListener("click", () => {
      optionBlock.remove();
    });

    optionBlock.appendChild(optionInput);
    optionBlock.appendChild(editOptBtn);
    optionBlock.appendChild(saveOptBtn);
    optionBlock.appendChild(deleteOptBtn);

    container.appendChild(optionBlock);
  }

  surveyForm.addEventListener("submit", async (e) => {
    e.preventDefault();

    const title = document.getElementById("surveyTitle").value;
    const questionBlocks = document.querySelectorAll(".questionBlock");

    const questions = Array.from(questionBlocks).map((qb) => {
      const questionText = qb.querySelector("input[name='question']").value;
      const optionInputs = qb.querySelectorAll("input[name='option']");
      const options = Array.from(optionInputs).map((o) => ({
        text: o.value,
      }));
      return { questionText, options };
    });

    try {
      const res = await fetch("http://localhost:3000/surveys", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
        body: JSON.stringify({ title, questions }),
      });
      if (res.ok) {
        feedback.textContent = "Umfrage erfolgreich gespeichert!";
        feedback.style.color = "green";
        questionsContainer.innerHTML = "";
        surveyForm.reset();
        loadSurveys();
      } else {
        const error = await res.json();
        feedback.textContent = error.message || "Fehler beim Speichern.";
        feedback.style.color = "red";
      }
    } catch (err) {
      console.error(err);
      feedback.textContent = "Unerwarteter Fehler.";
      feedback.style.color = "red";
    }
  });

  async function loadSurveys() {
    surveysList.innerHTML = "";
    try {
      const res = await fetch("http://localhost:3000/surveys", {
        headers: { Authorization: "Bearer " + localStorage.getItem("token") },
      });
      const surveys = await res.json();
      surveys.forEach((s) => {
        const div = document.createElement("div");
        div.classList.add("border", "p-2", "mb-2");

        const h5 = document.createElement("h5");
        h5.textContent = s.title;
        div.appendChild(h5);

        const delBtn = document.createElement("button");
        delBtn.textContent = "Löschen";
        delBtn.classList.add("btn", "btn-danger", "btn-sm", "me-2");
        delBtn.addEventListener("click", () => {
          deleteSurvey(s._id);
        });

        const editBtn = document.createElement("button");
        editBtn.textContent = "Bearbeiten";
        editBtn.classList.add("btn", "btn-warning", "btn-sm");
        editBtn.addEventListener("click", () => {
          const newTitle = prompt("Neuer Titel?", s.title);
          if (!newTitle) return;
          updateSurvey(s._id, newTitle, s.questions);
        });

        div.appendChild(delBtn);
        div.appendChild(editBtn);

        surveysList.appendChild(div);
      });
    } catch (err) {
      console.error("Fehler beim Laden:", err);
    }
  }

  async function deleteSurvey(id) {
    if (!confirm("Wirklich diese Umfrage löschen?")) return;
    try {
      const res = await fetch(`http://localhost:3000/surveys/${id}`, {
        method: "DELETE",
        headers: { Authorization: "Bearer " + localStorage.getItem("token") },
      });
      if (res.ok) {
        loadSurveys();
      } else {
        alert("Fehler beim Löschen!");
      }
    } catch (err) {
      console.error(err);
    }
  }

  async function updateSurvey(id, newTitle, questions) {
    try {
      const res = await fetch(`http://localhost:3000/surveys/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
        body: JSON.stringify({ title: newTitle, questions }),
      });
      if (res.ok) {
        loadSurveys();
      } else {
        alert("Fehler beim Update!");
      }
    } catch (err) {
      console.error(err);
    }
  }

  deleteAllBtn.addEventListener("click", async () => {
    if (!confirm("Wirklich ALLE Umfragen löschen?")) return;
    try {
      const res = await fetch("http://localhost:3000/surveys-all", {
        method: "DELETE",
        headers: { Authorization: "Bearer " + localStorage.getItem("token") },
      });
      if (res.ok) {
        alert("Alle Umfragen gelöscht.");
        loadSurveys();
      } else {
        alert("Fehler beim Löschen!");
      }
    } catch (err) {
      console.error(err);
    }
  });

  async function getAllSurveys() {
    const res = await fetch("http://localhost:3000/surveys", {
      headers: { Authorization: "Bearer " + localStorage.getItem("token") },
    });
    return res.json();
  }

  loadSurveys();
});
