exportAnswersCSV.addEventListener("click", async () => {
  const responses = await loadAllResponses();
  if (!responses.length) {
    alert("Keine Antworten vorhanden.");
    return;
  }
  let csvContent = "SurveyID;UserID;Frage;Auswahl\n";
  responses.forEach((r) => {
    r.answers.forEach((a) => {
      csvContent += `${r.surveyId};${r.userId};${a.question};${a.selectedOption}\n`;
    });
  });
  downloadCSV(csvContent, "antworten.csv");
});

exportAnswersPDF.addEventListener("click", async () => {
  const responses = await loadAllResponses();
  if (!responses.length) {
    alert("Keine Antworten vorhanden.");
    return;
  }
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  let yOffset = 10;

  responses.forEach((r) => {
    doc.text(`SurveyID: ${r.surveyId}`, 10, yOffset);
    yOffset += 6;
    doc.text(`UserID: ${r.userId}`, 10, yOffset);
    yOffset += 6;

    let rows = [];
    r.answers.forEach((a) => {
      rows.push([a.question, a.selectedOption]);
    });
    doc.autoTable({
      head: [["Frage", "Auswahl"]],
      body: rows,
      startY: yOffset,
    });
    yOffset = doc.previousAutoTable.finalY + 10;
  });

  doc.save("antworten.pdf");
});

function downloadCSV(csvString, filename) {
  const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
