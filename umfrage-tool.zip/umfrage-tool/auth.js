document
  .getElementById("registrationForm")
  .addEventListener("submit", async (e) => {
    e.preventDefault();

    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const role = document.getElementById("role").value;
    const feedback = document.getElementById("registrationFeedback");

    try {
      const response = await fetch("http://localhost:3000/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, email, password, role }),
      });

      if (response.ok) {
        feedback.textContent = "Registrierung erfolgreich!";
        feedback.style.color = "green";
      } else {
        const error = await response.json();
        feedback.textContent = error.message || "Fehler bei der Registrierung.";
        feedback.style.color = "red";
      }
    } catch (error) {
      feedback.textContent = "Unerwarteter Fehler.";
      feedback.style.color = "red";
    }
  });

document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("emailLogin").value;
  const password = document.getElementById("passwordLogin").value;
  const feedback = document.getElementById("loginFeedback");

  try {
    const response = await fetch("http://localhost:3000/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    if (response.ok) {
      const result = await response.json();
      feedback.textContent = "Login erfolgreich!";
      feedback.style.color = "green";
      localStorage.setItem("token", result.token);
      localStorage.setItem("role", result.role);

      if (result.role === "admin") {
        window.location.href = "survey.html";
      } else {
        window.location.href = "participant.html";
      }
    } else {
      const error = await response.json();
      feedback.textContent = error.message || "Login fehlgeschlagen.";
      feedback.style.color = "red";
    }
  } catch (error) {
    feedback.textContent = "Unerwarteter Fehler.";
    feedback.style.color = "red";
  }
});
